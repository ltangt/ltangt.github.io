package edu.cs.fiu.kdrg.stcan.core;

import java.io.Serializable;

import edu.fiu.cs.kdrg.stscan.alg.TemporalDependencyMiner;

public interface PatternConstraint extends Serializable{
	
	boolean satisfy(TemporalDependency p, TemporalDependencyMiner miner);

}
