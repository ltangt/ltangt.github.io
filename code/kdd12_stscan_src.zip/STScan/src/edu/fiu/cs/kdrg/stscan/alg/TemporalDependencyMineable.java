package edu.fiu.cs.kdrg.stscan.alg;

import java.util.Collection;
import java.util.List;

import edu.cs.fiu.kdrg.stcan.core.PatternConstraint;
import edu.cs.fiu.kdrg.stcan.core.TemporalDependency;

public interface TemporalDependencyMineable {
	
	 List<TemporalDependency> find(int topK, long maxInterval) throws InterruptedException;
	 
	 long getPeakMemCost();
	 
}
