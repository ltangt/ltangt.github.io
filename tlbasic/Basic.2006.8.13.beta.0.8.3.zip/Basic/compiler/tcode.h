#ifndef _TLBASIC_CODE_H_
#define _TLBASIC_CODE_H_

#include "tparse.h"
#include "tcodefile.h"

tCodeFile* tcode_gen(ParseTreeNode* parsetree);

#endif
