#ifndef _TLBASIC_API_H_
#define _TLBASIC_API_H_

#include "tNativeFunction.h"

#endif	 // _TLBASIC_API_H_
