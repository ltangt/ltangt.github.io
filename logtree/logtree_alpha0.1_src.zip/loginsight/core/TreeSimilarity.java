package loginsight.core;

public interface TreeSimilarity extends SimilarityFunction {
	
	double similarity(TreeNode t1, TreeNode t2);

}




