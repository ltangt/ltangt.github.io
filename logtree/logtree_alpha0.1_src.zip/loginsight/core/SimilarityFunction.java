package loginsight.core;

public interface SimilarityFunction {
	
	double similarity(Object o1, Object o2);
	
}
